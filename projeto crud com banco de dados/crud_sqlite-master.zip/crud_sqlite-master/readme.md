# PROJETO CRUD COM SQLITE E FLASK
Este projeto foi feito para uma aula específica da **Escola Koru** e só faz sentido quando apresentado neste contexto.

O objetivo geral do projeto é demonstrar aos alunos como podem utilizar o flask para realizar operações de CRUD utilizando templates, com base em um banco de dados SQLite.

O projeto apresenta erros intencionais e referencias inválidas a um projeto anterior, bem como ausências de códigos importantes. Estes detalhes serão discutidos ao longo da aplicação da aula e das atividades práticas que incluirão novas funcionalidades.

*Este repositório não será atualizado com as novas funcionalidades, sendo utilizado apenas para que os alunos obtenham os arquivos base necessários para as atividades práticas propostas em aula síncrona.*
